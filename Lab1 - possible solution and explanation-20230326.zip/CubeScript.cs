using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeScript : MonoBehaviour
{
    //public member GameObject will be visible outside in the editor
    public GameObject extGameObj;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // you can see that Update() is not called with a fixed framerate. 
        Debug.Log(Time.deltaTime); 

        //the property transform is invoked on the current GameObject (the one the script is attached to, in this case the cube)
        transform.Rotate(0.0f, 1.0f, 0.0f, Space.Self);

        //the property transform is invoked on extGameObj (declared in the public part of the class)
        extGameObj.transform.Rotate(0.1f, 0.0f, 0.0f);

    }

    void FixedUpdate()
    {
        // you can see that FixedUpdate() is called with a fixed framerate.
        //Debug.Log(Time.deltaTime);
    }

}
