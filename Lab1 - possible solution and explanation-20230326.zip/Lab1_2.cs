using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lab1_2 : MonoBehaviour
{
    private
        GameObject[] array = new GameObject[4];
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < 4; i++)
        {
            array[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            array[i].transform.position = new Vector3(i, 0.0f, 0.0f);
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        for(int i = 0; i < 4; i++)
        {
            array[i].transform.Rotate(0.1f*i, 0.0f, 0.0f);
        }
        
    }
}
