using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lab1 : MonoBehaviour
{
    private
        GameObject mycube, mysphere, mycapsule, mycylinder;
    // Start is called before the first frame update
    void Start()
    {
        mycube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        mycube.transform.position = new Vector3(0, 0.5f, 0);
        

        mysphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        mysphere.transform.position = new Vector3(0, 1.5f, 0);

        mycapsule = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        mycapsule.transform.position = new Vector3(2, 1, 0);

        mycylinder = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        mycylinder.transform.position = new Vector3(-2, 1, 0);

    }

    // Update is called once per frame
    void Update()
    {
        mycylinder.transform.Rotate(0.1f, 0.0f, 0.0f);
    }
}
